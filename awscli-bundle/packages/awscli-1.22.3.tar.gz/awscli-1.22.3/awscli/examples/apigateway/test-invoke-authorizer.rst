**To test invoke a request to a Custom Authorizer including the required header and value**

Command::

  aws apigateway test-invoke-authorizer --rest-api-id 1234123412 --authorizer-id 5yid1t --headers Authorization='Value'
